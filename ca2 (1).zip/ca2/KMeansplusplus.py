import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from random import seed, choice
from sklearn.metrics import silhouette_score

# Set a fixed random seed for reproducibility
seed(42)

# Load the dataset with conversion to float, handling different delimiters
def load_dataset(filename='dataset'):
    try:
        # Try reading with whitespace as the delimiter
        data = pd.read_csv(filename, header=None, delim_whitespace=True)
        print(f"Dataset shape before processing: {data.shape}")
        print(data.head())

        # Drop the first column assuming it is a label
        if data.shape[1] > 1:
            data = data.drop(columns=[0])
        else:
            print("Dataset has insufficient columns for clustering.")
            return np.array([])

        print(f"Dataset shape after dropping label column: {data.shape}")

        # Convert to float and handle conversion errors
        data = data.astype(float)
        return data.values

    except Exception as e:
        print(f"Error loading dataset: {e}")
        return np.array([])

# Function to compute distance between two points
def ComputeDistance(point1, point2):
    return np.linalg.norm(np.array(point1) - np.array(point2))

# KMeans++ initial selection of cluster representatives
def initialSelection(data, k):
    n_samples = data.shape[0]
    representatives = []
    # Step 1: Randomly choose the first representative
    representatives.append(data[np.random.randint(0, n_samples)])

    # Step 2: Select remaining k-1 representatives using KMeans++
    for _ in range(1, k):
        # Compute the distance to the nearest representative for each data point
        distances = np.array([min([ComputeDistance(point, rep) for rep in representatives]) for point in data])
        probabilities = distances / distances.sum()
        # Choose the next representative based on the computed probabilities
        next_rep = data[np.random.choice(range(n_samples), p=probabilities)]
        representatives.append(next_rep)

    return np.array(representatives)

# Function to assign cluster ids to each data point
def assignClusterIds(data, representatives):
    clusters = []
    for point in data:
        distances = [ComputeDistance(point, rep) for rep in representatives]
        clusters.append(np.argmin(distances))
    return np.array(clusters)

# Function to compute cluster representatives
def computeClusterRepresentatives(data, clusters, k):
    representatives = []
    for i in range(k):
        cluster_points = data[clusters == i]
        if len(cluster_points) > 0:
            representatives.append(cluster_points.mean(axis=0))
        else:
            representatives.append(data[np.random.randint(0, len(data))])
    return np.array(representatives)

# KMeans++ algorithm
def clustername(data, k, max_iterations=100):
    representatives = initialSelection(data, k)
    for _ in range(max_iterations):
        clusters = assignClusterIds(data, representatives)
        new_representatives = computeClusterRepresentatives(data, clusters, k)
        if np.allclose(representatives, new_representatives):
            break
        representatives = new_representatives
    return clusters

# Function to plot silhouette scores
def plot_silhouette(k_values, silhouette_scores):
    plt.figure()
    plt.plot(k_values, silhouette_scores, marker='o')
    plt.xlabel('Number of Clusters (k)')
    plt.ylabel('Silhouette Coefficient')
    plt.title('KMeans++ Clustering Silhouette Scores')
    plt.grid(True)
    plt.show()

# Main execution function
def main():
    data = load_dataset()
    if data.size == 0:
        print("No valid data loaded. Exiting.")
        return
    silhouette_scores = []
    k_values = range(1, 10)
    for k in k_values:
        if k == 1:
            silhouette_scores.append(0)  # Silhouette score is not defined for k=1
            continue
        clusters = clustername(data, k)
        score = silhouette_score(data, clusters)
        silhouette_scores.append(score)
    plot_silhouette(k_values, silhouette_scores)

if __name__ == '__main__':
    main()
