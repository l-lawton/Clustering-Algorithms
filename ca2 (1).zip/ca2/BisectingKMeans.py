import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from random import seed, sample
from sklearn.metrics import silhouette_score

# Set a fixed random seed for reproducibility
seed(42)

# Load the dataset with conversion to float, handling different delimiters
def load_dataset(filename='dataset'):
    try:
        # Try reading with whitespace as the delimiter
        data = pd.read_csv(filename, header=None, sep=r'\s+')
        print(f"Dataset shape before processing: {data.shape}")
        print(data.head())

        # Drop the first column assuming it is a label
        if data.shape[1] > 1:
            data = data.drop(columns=[0])
        else:
            print("Dataset has insufficient columns for clustering.")
            return np.array([])

        print(f"Dataset shape after dropping label column: {data.shape}")

        # Convert to float and handle conversion errors
        data = data.astype(float)
        return data.values

    except Exception as e:
        print(f"Error loading dataset: {e}")
        return np.array([])

# Function to compute distance between two points
def ComputeDistance(point1, point2):
    return np.linalg.norm(np.array(point1) - np.array(point2))

# Function to compute the sum of squared distances within a cluster
def computeSumOfSquare(data, cluster_ids, cluster_id):
    cluster_points = data[cluster_ids == cluster_id]
    if len(cluster_points) == 0:
        return 0
    centroid = cluster_points.mean(axis=0)
    return np.sum([ComputeDistance(point, centroid)**2 for point in cluster_points])

# KMeans algorithm for bisecting k-means
def KMeans(data, k, max_iterations=100):
    n_samples = len(data)
    representatives = data[sample(range(n_samples), k)]
    for _ in range(max_iterations):
        clusters = np.array([np.argmin([ComputeDistance(point, rep) for rep in representatives]) for point in data])
        new_representatives = np.array([data[clusters == i].mean(axis=0) if np.any(clusters == i) else representatives[i] for i in range(k)])
        if np.allclose(representatives, new_representatives):
            break
        representatives = new_representatives
    return clusters

# Bisecting KMeans algorithm
def BisectingKMeans(data, max_clusters=9):
    # Start with a single cluster
    clusters = np.zeros(len(data), dtype=int)
    current_cluster_count = 1

    while current_cluster_count < max_clusters:
        # Choose the cluster to split
        cluster_to_split = np.argmax([computeSumOfSquare(data, clusters, i) for i in range(current_cluster_count)])
        cluster_data = data[clusters == cluster_to_split]
        # Split the chosen cluster into two using standard KMeans
        split_clusters = KMeans(cluster_data, 2)
        # Assign new cluster IDs correctly
        split_mask = np.where(clusters == cluster_to_split)[0]
        clusters[split_mask[split_clusters == 1]] = current_cluster_count
        current_cluster_count += 1

    return clusters

# Function to plot silhouette scores
def plot_silhouette(s_values, silhouette_scores):
    plt.figure()
    plt.plot(s_values, silhouette_scores, marker='o')
    plt.xlabel('Number of Clusters (s)')
    plt.ylabel('Silhouette Coefficient')
    plt.title('Bisecting KMeans Clustering Silhouette Scores')
    plt.grid(True)
    plt.show()

# Main execution function
def main():
    data = load_dataset()
    if data.size == 0:
        print("No valid data loaded. Exiting.")
        return
    silhouette_scores = []
    s_values = range(1, 10)
    for s in s_values:
        if s == 1:
            silhouette_scores.append(0)  # Silhouette score is not defined for s=1
            continue
        clusters = BisectingKMeans(data, max_clusters=s)
        if len(np.unique(clusters)) < 2:
            print(f"Invalid clustering for s={s}: only one cluster found.")
            silhouette_scores.append(0)
            continue
        score = silhouette_score(data, clusters)
        silhouette_scores.append(score)
    plot_silhouette(s_values, silhouette_scores)

if __name__ == '__main__':
    main()
