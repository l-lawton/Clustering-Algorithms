import numpy as np
import matplotlib.pyplot as plt
from random import seed
from sklearn.metrics import silhouette_score
from sklearn.datasets import make_blobs

# Set a fixed random seed for reproducibility
seed(42)

# Function to generate synthetic data with the same size as the original dataset
def generate_synthetic_data(samples=327, features=300, centers=5, random_state=42):
    data, _ = make_blobs(n_samples=samples, n_features=features, centers=centers, random_state=random_state)
    return data

# Function to compute distance between two points
def ComputeDistance(point1, point2):
    return np.linalg.norm(np.array(point1) - np.array(point2))

# Function to choose initial cluster representatives
def initialSelection(data, k):
    indices = np.random.choice(len(data), k, replace=False)
    return data[indices]

# Function to assign cluster ids to each data point
def assignClusterIds(data, representatives):
    clusters = []
    for point in data:
        distances = [ComputeDistance(point, rep) for rep in representatives]
        clusters.append(np.argmin(distances))
    return np.array(clusters)

# Function to compute cluster representatives
def computeClusterRepresentatives(data, clusters, k):
    representatives = []
    for i in range(k):
        cluster_points = data[clusters == i]
        if len(cluster_points) > 0:
            representatives.append(cluster_points.mean(axis=0))
        else:
            representatives.append(data[np.random.randint(0, len(data))])
    return np.array(representatives)

# KMeans algorithm
def clustername(data, k, max_iterations=100):
    representatives = initialSelection(data, k)
    for _ in range(max_iterations):
        clusters = assignClusterIds(data, representatives)
        new_representatives = computeClusterRepresentatives(data, clusters, k)
        if np.allclose(representatives, new_representatives):
            break
        representatives = new_representatives
    return clusters

# Function to plot silhouette scores
def plot_silhouette(k_values, silhouette_scores):
    plt.figure()
    plt.plot(k_values, silhouette_scores, marker='o')
    plt.xlabel('Number of Clusters (k)')
    plt.ylabel('Silhouette Coefficient')
    plt.title('KMeans Clustering on Synthetic Data')
    plt.grid(True)
    plt.show()

# Main execution function
def main():
    data = generate_synthetic_data()
    silhouette_scores = []
    k_values = range(1, 10)
    for k in k_values:
        if k == 1:
            silhouette_scores.append(0)  # Silhouette score is not defined for k=1
            continue
        clusters = clustername(data, k)
        score = silhouette_score(data, clusters)
        silhouette_scores.append(score)
    plot_silhouette(k_values, silhouette_scores)

if __name__ == '__main__':
    main()
