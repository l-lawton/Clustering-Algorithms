from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
import numpy as np

# True labels based on color classes (Red = 0, Purple = 1, Blue = 2)
true_labels = [0]*3 + [1]*2 + [2]*3 + [0]*2 + [1]*1 + [2]*6 + [0]*1 + [1]*2 + [2]*5

# Predicted clusters (Cluster 1 = 0, Cluster 2 = 1, Cluster 3 = 2)
predicted_labels = [0]*8 + [1]*9 + [2]*8

# Compute the confusion matrix
conf_matrix = confusion_matrix(true_labels, predicted_labels, labels=[0, 1, 2])

# Compute macro-averaged Precision, Recall, and F-score
precision = precision_score(true_labels, predicted_labels, average='macro')
recall = recall_score(true_labels, predicted_labels, average='macro')
f1 = f1_score(true_labels, predicted_labels, average='macro')

print("Confusion Matrix:")
print(conf_matrix)
print(f"\nMacro-averaged Precision: {precision:.3f}")
print(f"Macro-averaged Recall: {recall:.3f}")
print(f"Macro-averaged F-Score: {f1:.3f}")

# B-CUBED Precision, Recall, and F-score calculation
def bcubed_precision_recall_fscore(true_labels, predicted_labels):
    n = len(true_labels)
    precision_list = []
    recall_list = []
    for i in range(n):
        same_cluster_pred = {j for j in range(n) if predicted_labels[j] == predicted_labels[i]}
        same_class_true = {j for j in range(n) if true_labels[j] == true_labels[i]}
        precision_list.append(len(same_cluster_pred & same_class_true) / len(same_cluster_pred))
        recall_list.append(len(same_cluster_pred & same_class_true) / len(same_class_true))
    precision = np.mean(precision_list)
    recall = np.mean(recall_list)
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    return precision, recall, f1

# Calculate B-CUBED scores
bcubed_precision, bcubed_recall, bcubed_f1 = bcubed_precision_recall_fscore(true_labels, predicted_labels)
print(f"\nB-CUBED Precision: {bcubed_precision:.3f}")
print(f"B-CUBED Recall: {bcubed_recall:.3f}")
print(f"B-CUBED F-Score: {bcubed_f1:.3f}")
